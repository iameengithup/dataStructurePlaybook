import java.util.Arrays;

/**
 * 
 */

/**
 * @author Irfan Ameen
 * @version 03/15/2020
 * This class demonstrates bubble sort implementation 
 */

public class BubbleSortImpl {

		    /*
		     * Sort Array using bubble Sort starting from 0 position of array comparing with next element 
		     * Swap when next element is lesser than current position element
		     * Repeat this process until there are no elements to be swapped and array is sorted
		     */
		    public static void sort(int[] unsorted) {

		        for (int pos = 0; pos < unsorted.length; pos++) {
		            for (int nextPos = unsorted.length -1; nextPos > pos; nextPos--) {
		                if (unsorted[nextPos] < unsorted[nextPos - 1]) {
		                    swap(unsorted, nextPos, nextPos-1);
		                }
		            }
		        }
		        System.out.printf("Sorted Array :%s %n",Arrays.toString(unsorted));
		    }
		    
		    //Compare and Swap next 
		    public static void swap(int[] sortInProcess, int pos, int nextPos){
		        int tmp = sortInProcess[pos];
		        sortInProcess[pos] = sortInProcess[nextPos];
		        sortInProcess[nextPos] = tmp;
		    }
		    
		    public static void main(String args[]) {
		    	//To be sorted Array 
				   sort(new int[] { 20, 12, 45, 19, 91, 55 });
			    }
		 
		}